﻿

#include <iostream>
#include <locale>
#include <math.h>

int main() {
	float x1, x2;
	scanf_s("%f", &x2);
	x1 = -9999999999.9999;
	while (!(x2< x1)) {
		x1 = x2;
		printf("%f\n", x2);
		scanf_s("%f", &x2);
	}



}


